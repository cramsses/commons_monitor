package com.sabadell.MonitorAmbientesBatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonitorAmbientesBatchApplication {
	public static void main(String[] args) {
		SpringApplication.run(MonitorAmbientesBatchApplication.class, args);
	}
}
