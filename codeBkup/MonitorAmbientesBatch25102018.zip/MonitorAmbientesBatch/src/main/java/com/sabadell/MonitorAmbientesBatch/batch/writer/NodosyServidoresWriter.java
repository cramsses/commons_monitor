package com.sabadell.MonitorAmbientesBatch.batch.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

import com.sabadell.MonitorAmbientesBatch.dto.MONTOperacionDTO;

public class NodosyServidoresWriter implements ItemWriter<MONTOperacionDTO> {

	public NodosyServidoresWriter() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void write(List<? extends MONTOperacionDTO> items) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
