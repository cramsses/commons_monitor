package com.sabadell.MonitorAmbientesBatch.dto;

import java.util.Date;

public class MONTOperacionDTO {

	public MONTOperacionDTO() {
		// TODO Auto-generated constructor stub
	}
	
	private Integer idOperacion;
	private MONAServidoresDTO monaServidoresDTO;//private Integer idServidor;
	private Integer idEstatus;
	private Date fecha;
	private Double tiempoRespuesta;
	
	public Integer getIdOperacion() {
		return idOperacion;
	}
	public void setIdOperacion(Integer idOperacion) {
		this.idOperacion = idOperacion;
	}
	
	public MONAServidoresDTO getMonaServidoresDTO() {
		return monaServidoresDTO;
	}
	public void setMonaServidoresDTO(MONAServidoresDTO monaServidoresDTO) {
		this.monaServidoresDTO = monaServidoresDTO;
	}
	public Integer getIdEstatus() {
		return idEstatus;
	}
	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public Double getTiempoRespuesta() {
		return tiempoRespuesta;
	}
	public void setTiempoRespuesta(Double tiempoRespuesta) {
		this.tiempoRespuesta = tiempoRespuesta;
	}
	@Override
	public String toString() {
		return "MONTOperacionDTO [idOperacion=" + idOperacion + ", monaServidoresDTO=" + monaServidoresDTO
				+ ", idEstatus=" + idEstatus + ", fecha=" + fecha + ", tiempoRespuesta=" + tiempoRespuesta + "]";
	}


}
