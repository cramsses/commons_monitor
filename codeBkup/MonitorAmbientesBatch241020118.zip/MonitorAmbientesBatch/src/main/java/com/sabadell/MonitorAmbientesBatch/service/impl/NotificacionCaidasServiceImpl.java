package com.sabadell.MonitorAmbientesBatch.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sabadell.MonitorAmbientesBatch.batch.dao.OperacionDAO;
import com.sabadell.MonitorAmbientesBatch.dto.MONTOperacionDTO;
import com.sabadell.MonitorAmbientesBatch.service.NotificacionCaidasService;
import com.sabadell.MonitorAmbientesBatch.utils.Utils;

@Service
public class NotificacionCaidasServiceImpl implements NotificacionCaidasService {

	private static final Logger LOGGER = Logger.getLogger(NotificacionCaidasServiceImpl.class);
	
	private static Set<Integer> lsIdServidoresCaidos;
	private Set<Integer> lsIdServidoresCaidosANotificar;
	
	private static Calendar banderaTiempo;
	
	@Autowired
	private OperacionDAO operacionDAO;
	
	@Override
	public void notificarCaidas() {
		/*
		 * Pasos
		 * 1.- Obtener última corrida de Base de Datos de la tabla operaciones
		 * 2.- Agregar los ids  los servidores caidos no repetidos
		 * 	2.1.- Se valida si ya esta registrado como caido en lista(mapa) de caidos
		 * 	2.2.- Si no esta se agrega a lista(mapa) de caidos
		 * 	2.3.- Si no esta se agrega tambien a lista(mapa) de caidos a Notificar
		 * 3.- Enviar correo de caidos nuevos
		 *  3.1 Si la lista de caidos a notificar NO es VACIA se llama a método de correo
		*/
		
		//Inicializar lista de caidos si es null, osea se resetea despues de la hora
		if(lsIdServidoresCaidos == null){
			lsIdServidoresCaidos = new HashSet<Integer>();
			//Setear bandera de tiempo
			banderaTiempo = Calendar.getInstance();
			
			
		}
		//Inicializar lista de caidos a notificar
		lsIdServidoresCaidosANotificar =  new HashSet<Integer>();
		
		//1 Retrieve operaciones (Objeto MONTOperacionDTO)
		//2. Validar caidos y agregar a listas
		
		for(MONTOperacionDTO op: operacionDAO.obtenerDatosRecientes()) {
			LOGGER.info(op);
			if(op.getIdEstatus() != Utils.OK_STATUS) {
				LOGGER.info("Servidor: "+op.getMonaServidoresDTO().getIdServidor()+" CAIDO con estatus: "+op.getIdEstatus());
				
				
				if(lsIdServidoresCaidos.add(op.getMonaServidoresDTO().getIdServidor())) {
					//Se agrega nuevo
					lsIdServidoresCaidosANotificar.add(op.getMonaServidoresDTO().getIdServidor());
				}
			}
			
		}
		LOGGER.info("Caidos: "+lsIdServidoresCaidos.size());
		LOGGER.info("Caidos a notificar: "+lsIdServidoresCaidosANotificar.size());
		
		
		
		
		//3. Enviar correo
		
		
		
		//Validar si se tiene que limpiar 
		Calendar now=Calendar.getInstance();
		long seconds = (now.getTimeInMillis() - banderaTiempo.getTimeInMillis()) / 1000;
		int hours = (int) (seconds / 3600);
		int minutes = (int) (seconds / 60);
		
		LOGGER.info("seconds: "+seconds+" minutes: "+minutes+" hours: "+hours);
		
		if(minutes>= 59) {
			//Limpiar listaCaidas
			lsIdServidoresCaidos=null;
		}
		
		
		
		
		

	}

}
