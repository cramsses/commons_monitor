package com.sabadell.MonitorAmbientesBatch.batch.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.sabadell.MonitorAmbientesBatch.service.NotificacionCaidasService;
import com.sabadell.MonitorAmbientesBatch.utils.email.EmailDTO;
import com.sabadell.MonitorAmbientesBatch.utils.email.EmailService;

@Component
@EnableScheduling
public class MonitorAmbientesBatchController {
	
	private static final Logger LOGGER = Logger.getLogger(MonitorAmbientesBatchController.class);
	
    @Autowired
    JobLauncher jobLauncher;
    
    @Autowired
    EmailService emailService;
    
    @Autowired
    NotificacionCaidasService notificacionCaidasService;
 
    @Autowired
    @Qualifier("monitorAmbientesJob")
    Job monitorAmbientesJob;
    
//    @Scheduled(cron="0 0/1 * * * *")
//    public void monitorear() throws Exception {
//    	jobLauncher.run(monitorAmbientesJob, new JobParametersBuilder()
//    	        .addDate("date", new Date())
//    	        .toJobParameters());
//    }
    
    @Scheduled(cron="0 0/1 * * * *")
    public void notificar() throws Exception {
    	LOGGER.info("----- PROCESO DE NOTIFICACION -----");
    	notificacionCaidasService.notificarCaidas();
    }
    
    //Todo llamar servicio de consulta y noticificación
    
//    @Scheduled(cron="45 28 */1 * * *")
//    public void vaciarCaidas() throws Exception {
//    	LOGGER.info("Clear lista");
//    	lsIdServerCaidos.clear();
//    }
    
    
    
    @Scheduled(cron="0 0/5 * * * *")
    public void notificacionTest() throws Exception {
		LOGGER.info("Notificacion MAIL");
		String from = "pavan@localhost";
		String to = "cramsses@gmail.com,jesus.alfredo.hernandez.orozco@everis.com";
		String subject = "Java Mail with Spring Boot";
		String message = "Texto prueba sin Template y con DTO";

		EmailDTO email = new EmailDTO(from, to, subject, message);
		email.setHtml(true);
		emailService.send(email);
		
    	emailService.send();
    }

}
