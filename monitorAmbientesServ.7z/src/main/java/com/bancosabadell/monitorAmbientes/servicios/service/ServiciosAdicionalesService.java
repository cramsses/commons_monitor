package com.bancosabadell.monitorAmbientes.servicios.service;

import java.text.ParseException;

import com.bancosabadell.monitorAmbientes.dto.MoncNodosDTO;
import com.bancosabadell.monitorAmbientes.dto.MoncURLDTO;

/**
 * Servicio que se utiliza para obtener distintos valores del sistema.
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
public interface ServiciosAdicionalesService {

	/**
	 * Obtiene la hora del sistema y le asigna un formato retornandola como String
	 * @param formatoDeFecha Formato de fecha a utilizar
	 * @return String de la fecha con el formato solicitado.
	 */
	String obtenerHoraDelSistema(String formatoDeHora) throws ParseException;

	/**
	 * Obtiene el nombre y la IP del nodo a partir del nombre corto del ambiente
	 * 
	 * @param nombreCorto Nombre corto del ambiente. Ejemplo: Desarrollo, DES.
	 * @param indice Registro aconsultar en BD
	 * @return Objeto con el nombre y la IP del nodo a partir del nombre corto del ambiente
	 */
	MoncNodosDTO obtenerDatosDeNodo(String nombreCorto, Integer indice);
	
	
	MoncURLDTO obtenerDatoURL(String nombreCorto, Integer indice);

}
