package com.bancosabadell.monitorAmbientes.servicios.service.impl;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.bancosabadell.monitorAmbientes.catalogos.dao.MoncNodosDAO;
import com.bancosabadell.monitorAmbientes.catalogos.dao.MoncUrlsDAO;
import com.bancosabadell.monitorAmbientes.dto.MoncNodosDTO;
import com.bancosabadell.monitorAmbientes.dto.MoncURLDTO;
import com.bancosabadell.monitorAmbientes.servicios.dao.ServiciosAdicionalesDAO;
import com.bancosabadell.monitorAmbientes.servicios.service.ServiciosAdicionalesService;
import com.bancosabadell.monitorAmbientes.utils.Utils;

/**
 * Servicio que se utiliza para obtener distintos valores del sistema.
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
@Service
public class ServiciosAdicionalesServiceImpl implements ServiciosAdicionalesService {

	public ServiciosAdicionalesServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	
	@Autowired
	private ServiciosAdicionalesDAO serviciosAdicionalesDAO;
	
	@Autowired
	private MoncNodosDAO moncNodosDAO;
	
	@Autowired
	private MoncUrlsDAO moncUrlsDAO;
	
	private static final Logger LOGGER = Logger.getLogger(ServiciosAdicionalesServiceImpl.class);

	/**
	 * Obtiene la hora del sistema y le asigna un formato retornandola como String
	 * 
	 * @param formatoDeFecha Formato de fecha a utilizar
	 * @return String de la fecha con el formato solicitado.
	 * @throws ParseException 
	 */
	@Override
	@Transactional(isolation = Isolation.DEFAULT, readOnly = true)
	public String obtenerHoraDelSistema(String formatoDeFecha) throws ParseException {
		return Utils.darFormatoFecha(formatoDeFecha, serviciosAdicionalesDAO.obtenerHoraDelSistema());
	}

	/**
	 * Obtiene el nombre y la IP del nodo a partir del nombre corto del ambiente
	 * 
	 * @param nombreCorto Nombre corto del ambiente. Ejemplo: Desarrollo, DES.
	 * @param indice Registro aconsultar en BD
	 * @return Objeto con el nombre y la IP del nodo a partir del nombre corto del ambiente
	 */
	@Override
	@Transactional(isolation = Isolation.DEFAULT, readOnly = true)
	public MoncNodosDTO obtenerDatosDeNodo(String nombreCorto, Integer indice) {
		LOGGER.info("nombreCorto: " +nombreCorto+" indice: "+indice);
		return moncNodosDAO.obtenerInformacionDeNodoPorNombreCorto(nombreCorto, indice);
	}
	
	/**
	 * Obtiene la URL del nodo a partir del nombre corto del ambiente
	 * 
	 * @param nombreCorto Nombre corto del ambiente. Ejemplo: Desarrollo, DES.
	 * @param indice Registro aconsultar en BD
	 * @return Objeto con el nombre y la IP del nodo a partir del nombre corto del ambiente
	 */
	@Override
	@Transactional(isolation = Isolation.DEFAULT, readOnly = true)
	public MoncURLDTO obtenerDatoURL(String nombreCorto, Integer indice) {
		LOGGER.info("nombreCorto: " +nombreCorto+" indice: "+indice);
		return moncUrlsDAO.obtenerInformacionDeURLPorNombreCorto(nombreCorto, indice);
	}

}
