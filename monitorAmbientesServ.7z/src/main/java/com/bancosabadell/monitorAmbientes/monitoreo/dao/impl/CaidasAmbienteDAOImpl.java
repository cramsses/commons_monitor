package com.bancosabadell.monitorAmbientes.monitoreo.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.bancosabadell.monitorAmbientes.monitoreo.dao.CaidasAmbienteDAO;
import com.bancosabadell.monitorAmbientes.monitoreo.dao.mapper.CaidasAmbienteMapper;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.CaidasAmbienteDTO;

/**
 * Interfaz que obtiene la informaci&oacute;n de las ca&iacute;das registradas en uno o varios
 * ambientes.
 * 
 * @author Jesus Alfredo Hernandez Orozco.
 *
 */
@Repository
public class CaidasAmbienteDAOImpl implements CaidasAmbienteDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final Logger LOGGER = Logger.getLogger(CaidasAmbienteDAOImpl.class);
	
	private static final 
	String QRY_CAIDAS_AMBIENTE="SELECT ambi.idambiente, ambi.nombreambiente,to_char(fecha,'HH24:MI') HORA,'1' count\r\n" + 
			"FROM mont_operacion oper \r\n" + 
			"INNER JOIN mona_servidores serv  ON oper.IDSERVIDOR=serv.IDSERVIDOR\r\n" + 
			"INNER JOIN monc_ambientes ambi  ON serv.IDAMBIENTE=ambi.IDAMBIENTE  \r\n" + 
			"WHERE (FECHA >= trunc(sysdate) And FECHA < trunc(sysdate) + 1)      \r\n" + 
			"AND oper.IDESTATUS not in (200, 401) \r\n"+
			"and serv.idservidor in (3,6,9,12,15,18,21,24,28,31,34,37,41,44,48)  \r\n" + 
			"group by ambi.idambiente,ambi.nombreambiente,to_char(fecha,'HH24:MI')";
	
	private static final
	String QRY_CAIDAS_BY_AMBIENTE="SELECT ambi.idambiente, ambi.nombreambiente,to_char(fecha,'HH24:MI') HORA,'1' count\r\n" + 
			"FROM mont_operacion oper \r\n" + 
			"INNER JOIN mona_servidores serv  ON oper.IDSERVIDOR=serv.IDSERVIDOR\r\n" + 
			"INNER JOIN monc_ambientes ambi  ON serv.IDAMBIENTE=ambi.IDAMBIENTE  \r\n" + 
			"WHERE (FECHA >= trunc(sysdate) And FECHA < trunc(sysdate) + 1)      \r\n" + 
			"AND oper.IDESTATUS not in (200, 401)\r\n" +
			"and serv.idservidor in (3,6,9,12,15,18,21,24,28,31,34,37,41,44,48)  \r\n" + 
			"AND ambi.NOMBRECORTO = ? \r\n" +
			"group by ambi.idambiente,ambi.nombreambiente,to_char(fecha,'HH24:MI')";
	
	private static final String OBTIENE_IDS_SERVIDOR_POR_NOMBRECORTO ="select  a.idservidor \r\n" + 
			"from mona_servidores a                                       \r\n" + 
			"inner join mona_url b on (a.idurl=b.idurl)                   \r\n" + 
			"inner join monc_ambientes c on (a.idambiente = c.idambiente) \r\n" + 
			"where c.nombrecorto=? \r\n" + 
			"order by a.idservidor";
	
	private static final String OBTIENE_CAIDAS_DE_URLS_POR_NOMBRECORTO = "SELECT serv.idservidor idambiente, serv.DESCRIPCIONSERVIDOR NOMBREAMBIENTE,to_char(fecha,'HH24:MI') HORA,'1' count \r\n" + 
			"FROM mont_operacion oper  \r\n" + 
			"INNER JOIN mona_servidores serv  ON oper.IDSERVIDOR=serv.IDSERVIDOR \r\n" + 
			"INNER JOIN monc_ambientes ambi  ON serv.IDAMBIENTE=ambi.IDAMBIENTE  \r\n" + 
			"WHERE (FECHA >= trunc(sysdate) And FECHA < trunc(sysdate) + 1)      \r\n" + 
			"AND oper.IDESTATUS not in (200, 401) \r\n" + 
			"AND serv.idservidor in ";


	@Override
	public List<CaidasAmbienteDTO> obtenerCaidasAmbiente() {
		List<CaidasAmbienteDTO> lista = null;
		try {
			lista = jdbcTemplate.query(QRY_CAIDAS_AMBIENTE, new CaidasAmbienteMapper());
		} catch (DataAccessException e) {
			lista = new ArrayList<CaidasAmbienteDTO>();
		}
		return lista;
	}


	@Override
	public List<CaidasAmbienteDTO> obtenerCaidasByNombreCortoAmbiente(String nombreCorto) {
		return jdbcTemplate.query(QRY_CAIDAS_BY_AMBIENTE, new Object[] {nombreCorto}, new CaidasAmbienteMapper());
	}

	/**
	 * Obtiene el listado de las caidas que ha habido en un nodo o en una URL de Bantotal o SOFOM.
	 * 
	 * @param idServidor ID del servidor.
	 * @return Listado de las caidas que ha habido en un nodo o en una URL de Bantotal o SOFOM.
	 */
	@Override
	public List<CaidasAmbienteDTO> obtenerCaidaDeNodoPorIdServidor(String query, String identificadorDeBusqueda) {
		return jdbcTemplate.query(query, new Object[] {identificadorDeBusqueda}, new CaidasAmbienteMapper());
	}


	/**
	 * Obtiene los identificadores de servidor que pertenecen a un nombre corto de ambiente.
	 * 
	 * @param nombreCorto nombre corto del ambiente que se pretende consultar.
	 * @return Lista de identificadores de servidor
	 */
	@Override
	public List<Integer> obtenerIDdeServidoresPorNombreCorto(String nombreCorto) {
		return jdbcTemplate.query(OBTIENE_IDS_SERVIDOR_POR_NOMBRECORTO, new Object[] {nombreCorto}, new RowMapper<Integer>(){
            public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
            	return rs.getInt(1);
            }
		});
	}

	/**
	 * Obtiene las caidas de las URL de un ambiente en particular filtrando por los IDs del servidor
	 */
	@Override
	public List<CaidasAmbienteDTO> obtenerCaidasDeAmbientePorNombreCorto(String ids) {
		List<CaidasAmbienteDTO> lista = null;
		
		LOGGER.info(OBTIENE_CAIDAS_DE_URLS_POR_NOMBRECORTO+ids+" order by serv.idservidor, hora");
		try {
			lista = jdbcTemplate.query(OBTIENE_CAIDAS_DE_URLS_POR_NOMBRECORTO+ids+" order by serv.idservidor, hora", new CaidasAmbienteMapper());
			
		} catch (EmptyResultDataAccessException e) {
			lista = new ArrayList<CaidasAmbienteDTO>();
		}
		return lista;
	}

}