package com.bancosabadell.monitorAmbientes.monitoreo.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.TiempoRespuestaAmbienteDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.TiempoRespuestaAmbienteIndicadorDTO;

public class TiempoRespuetaAmbientenIndicadorMapper implements RowMapper<TiempoRespuestaAmbienteIndicadorDTO> {

	public TiempoRespuetaAmbientenIndicadorMapper()  {
		// TODO Auto-generated constructor stub
	}

	@Override
	public TiempoRespuestaAmbienteIndicadorDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		TiempoRespuestaAmbienteIndicadorDTO objeto = new TiempoRespuestaAmbienteIndicadorDTO();
		objeto.setIdAmbiente(rs.getInt("IDAMBIENTE"));
		objeto.setAmbiente(rs.getString("NOMBREAMBIENTE"));
		objeto.setTiempoRespAvg(rs.getFloat("AVG"));
		objeto.setTiempoRespMax(rs.getFloat("MAX"));
		objeto.setTiempoRespMin(rs.getFloat("MIN"));
		return objeto;
	}

}