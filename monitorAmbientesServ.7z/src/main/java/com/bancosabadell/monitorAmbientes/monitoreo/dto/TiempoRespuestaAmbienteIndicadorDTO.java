package com.bancosabadell.monitorAmbientes.monitoreo.dto;

public class TiempoRespuestaAmbienteIndicadorDTO {
	
	private int idAmbiente;
	private String ambiente;
	private float tiempoRespAvg;
	private float tiempoRespMax;
	private float tiempoRespMin;
	public int getIdAmbiente() {
		return idAmbiente;
	}
	public void setIdAmbiente(int idAmbiente) {
		this.idAmbiente = idAmbiente;
	}
	public String getAmbiente() {
		return ambiente;
	}
	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}
	public float getTiempoRespAvg() {
		return tiempoRespAvg;
	}
	public void setTiempoRespAvg(float tiempoRespAvg) {
		this.tiempoRespAvg = tiempoRespAvg;
	}
	public float getTiempoRespMax() {
		return tiempoRespMax;
	}
	public void setTiempoRespMax(float tiempoRespMax) {
		this.tiempoRespMax = tiempoRespMax;
	}
	public float getTiempoRespMin() {
		return tiempoRespMin;
	}
	public void setTiempoRespMin(float tiempoRespMin) {
		this.tiempoRespMin = tiempoRespMin;
	}
	
}
