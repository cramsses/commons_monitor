package com.bancosabadell.monitorAmbientes.monitoreo.service;

public interface MonitorHttpService {
	String contarTiempoDeRespuesta();
}
