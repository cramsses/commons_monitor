package com.bancosabadell.monitorAmbientes.monitoreo.dao;

import java.util.List;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.TiempoRespuestaAmbienteDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.TiempoRespuestaAmbienteIndicadorDTO;

public interface TiempoRespuestaAmbienteDAO {

	List<TiempoRespuestaAmbienteDTO> obtenerTiemposRespuestaAmbiente();
	List<TiempoRespuestaAmbienteDTO> obtenerTiemposRespuestaByAmbiente(String nombreCorto);
	List<TiempoRespuestaAmbienteIndicadorDTO> obtenerIndicadoresTiemposRespuestaByAmbiente(String nombreCorto);
	
	
	
}
