package com.bancosabadell.monitorAmbientes.monitoreo.dto;

public class DisponibiliadAmbientesDTO {

	private String ambiente;
	private float disponibilidad;
	private int idEstatus;
	
	public int getIdEstatus() {
		return idEstatus;
	}
	public void setIdEstatus(int idEstatus) {
		this.idEstatus = idEstatus;
	}
	public String getAmbiente() {
		return ambiente;
	}
	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}
	public float getDisponibilidad() {
		return disponibilidad;
	}
	public void setDisponibilidad(float disponibilidad) {
		this.disponibilidad = disponibilidad;
	}
}
