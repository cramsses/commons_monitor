package com.bancosabadell.monitorAmbientes.monitoreo.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.MONTOperacionDTO;


public class OperacionesMapper implements RowMapper<MONTOperacionDTO> {

	public OperacionesMapper()  {
	}
 
	@Override
	public MONTOperacionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		MONTOperacionDTO objeto = new MONTOperacionDTO();
		objeto.setIdOperacion(rs.getInt("IDOPERACION"));
		objeto.setIdServidor(rs.getInt("IDSERVIDOR"));
		objeto.setIdEstatus(rs.getInt("IDESTATUS"));
		objeto.setFecha(rs.getDate("FECHA"));
		objeto.setTiempoRespuesta(rs.getDouble("TIEMPORESPUESTA"));
		objeto.setIdTipoVerificacion(rs.getInt("IDTIPOVERIFICACION"));
		return objeto;
	}

}