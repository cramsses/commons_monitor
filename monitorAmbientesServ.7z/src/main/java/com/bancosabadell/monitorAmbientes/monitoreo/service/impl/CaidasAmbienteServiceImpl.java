package com.bancosabadell.monitorAmbientes.monitoreo.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bancosabadell.monitorAmbientes.catalogos.dao.MonaServidoresDao;
import com.bancosabadell.monitorAmbientes.dto.MonaServidoresDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.dao.CaidasAmbienteDAO;
import com.bancosabadell.monitorAmbientes.monitoreo.dao.OperacionDAO;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.AmbienteConEstatusDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.CaidasAmbienteDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.MONTOperacionDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.TiemposCaidaServidorDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.service.CaidasAmbienteService;
import com.bancosabadell.monitorAmbientes.monitoreo.service.MonitorHttpOnDemandService;
import com.bancosabadell.monitorAmbientes.utils.Utils;

/**
 * Obtiene todos los datos relacionados con las caidas del servicio por
 * ambiente.
 * 
 * @author Jesus Alfredo Hernandez Orozco
 * @author Edgar Ramsses Solis Hernandez
 *
 */
@Service
public class CaidasAmbienteServiceImpl implements CaidasAmbienteService {
	
	@Autowired
	private MonitorHttpOnDemandService monitorHttpOnDemandService;
	
	private static final int MINUTO_59 = 59;
	
	private static final String BUSQUEDA_POR_NODO = "SELECT ambi.idambiente, ambi.nombreambiente,to_char(fecha,'HH24:MI') HORA, decode(oper.IDESTATUS, 200, 0, 401, 0,  1) count \r\n" + 
			"FROM mont_operacion oper  \r\n" + 
			"INNER JOIN mona_servidores serv  ON oper.IDSERVIDOR=serv.IDSERVIDOR \r\n" + 
			"INNER JOIN monc_ambientes  ambi  ON serv.IDAMBIENTE=ambi.IDAMBIENTE \r\n" + 
			"inner join monc_nodos      NODOS ON (nodos.idnodo = serv.idnodo)    \r\n" + 
			"inner join mona_url        URLS  on (serv.idurl = URLS.idurl)       \r\n" + 
			"WHERE (FECHA >= trunc(sysdate) And FECHA < trunc(sysdate) + 1)      \r\n" + 
			"AND NODOS.NOMNODO= ? \r\n" + 
			"order by hora";
	
	private static final String BUSQUEDA_POR_URL = "SELECT ambi.idambiente, ambi.nombreambiente,to_char(fecha,'HH24:MI') HORA, decode(oper.IDESTATUS, 200, 0, 401, 0,  1) count \r\n" + 
			"FROM mont_operacion oper  \r\n" + 
			"INNER JOIN mona_servidores serv  ON oper.IDSERVIDOR=serv.IDSERVIDOR \r\n" + 
			"INNER JOIN monc_ambientes  ambi  ON serv.IDAMBIENTE=ambi.IDAMBIENTE \r\n" + 
			"inner join monc_nodos      NODOS ON (nodos.idnodo = serv.idnodo)    \r\n" + 
			"inner join mona_url        URLS  on (serv.idurl = URLS.idurl)       \r\n" + 
			"WHERE (FECHA >= trunc(sysdate) And FECHA < trunc(sysdate) + 1)      \r\n" + 
			"AND urls.idURL = ? \r\n" + 
			"order by hora";
	private static final Logger LOGGER = Logger.getLogger(CaidasAmbienteServiceImpl.class);

	@Autowired
	private CaidasAmbienteDAO caidasAmbienteDAO;
	
	@Autowired
	private MonaServidoresDao monaServidoresDao;
	
	@Autowired
	private OperacionDAO operacionDAO;
	
	

	public CaidasAmbienteServiceImpl() {
	}

	@Override
	public List<CaidasAmbienteDTO> obtenerCaidas() {
		return caidasAmbienteDAO.obtenerCaidasAmbiente();
	}

	@Override
	public List<CaidasAmbienteDTO> obtenerCaidasByNombreCorto(String nombreCorto) {
		return caidasAmbienteDAO.obtenerCaidasByNombreCortoAmbiente(nombreCorto);
	}

	/**
	 * Obtiene el estatus de la caida de un nodo, ya sea a trav&eacute;s de la URL o el estado del nodo.
	 * 
	 */
	@Override
	public List<CaidasAmbienteDTO> obtenerCaidaDeNodoPorIdServidor(String identificadorDeBusqueda, Integer bandera) {
		
		List<CaidasAmbienteDTO> lista = null;
		try {
			lista=caidasAmbienteDAO.obtenerCaidaDeNodoPorIdServidor(determinarQueryAUtilizar(bandera), identificadorDeBusqueda);
		} catch (Exception e) {
			LOGGER.error(e.getCause());
		}
		return lista;
	}

	/**
	 * Obtiene las caidas de las URL de un ambiente en particular filtrando por los IDs del servidor
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly=true)
	public List<CaidasAmbienteDTO> obtenerCaidasDeAmbientePorNombreCorto(String nombreCorto) {
		List <Integer> listaDeIdDeServidores = caidasAmbienteDAO.obtenerIDdeServidoresPorNombreCorto(nombreCorto);
		return caidasAmbienteDAO.obtenerCaidasDeAmbientePorNombreCorto(retornarIds(listaDeIdDeServidores));
	}
	
	private String retornarIds(List <Integer> listaDeIdDeServidores) {
		StringBuilder idServidores = new StringBuilder();
		idServidores.append("(");
		for (Integer id : listaDeIdDeServidores) {
			idServidores.append(id+",");
		}
		idServidores.append(")");
		return idServidores.toString().replace(",)", ")");
	}
	

	/**
	 * Indica si la informaci&oacute;n a mostrar viene del historial de nodos o de URLS
	 * 
	 * @param bandera
	 * @return
	 */
	private String determinarQueryAUtilizar(Integer bandera) {
		String query = null;
		if(bandera == 1) {
			query = BUSQUEDA_POR_NODO;
		} else {
			query = BUSQUEDA_POR_URL;
		}
		return query;
	}
	
	/**
	 * Obtiene las ca&iacute;das regstradas de cada nodo de un ambiente en particular.
	 * 
	 * @param nombreCorto Nombre corto del ambiente
	 * @return lista de las ca&iacute;das regstradas de cada nodo de un ambiente en particular.
	 */
	@Override
	public List<CaidasAmbienteDTO> contarCaidasDeAmbientePorNombreCorto(String nombreCorto) {
		String ids = null;
		CaidasAmbienteDTO objetoAmbiente = null;
		List<CaidasAmbienteDTO> listaConteoFinal = new ArrayList<CaidasAmbienteDTO>();
		
		List <Integer> listaDeIdDeServidores = caidasAmbienteDAO.obtenerIDdeServidoresPorNombreCorto(nombreCorto);
		
		ids = retornarIds(listaDeIdDeServidores);
		List<CaidasAmbienteDTO> lista = caidasAmbienteDAO.obtenerCaidasDeAmbientePorNombreCorto(ids);		
		
		for (MonaServidoresDTO objServidor : monaServidoresDao.obtenerServidoresPorIDs(ids)) {
			objetoAmbiente = new CaidasAmbienteDTO();
			objetoAmbiente.setIdAmbiente(objServidor.getIdServidor());
			objetoAmbiente.setAmbiente(objServidor.getDescripcion());
			objetoAmbiente.setNumCaidas(0);
			objetoAmbiente.setHora("");
			listaConteoFinal.add(objetoAmbiente);
		}
		
		List<CaidasAmbienteDTO> listaDeConteos = obtenerConteoDeCaidas(lista);
		
		for(CaidasAmbienteDTO datosFinal: listaConteoFinal) {
			for (CaidasAmbienteDTO datos: listaDeConteos) {
				if(datosFinal.getIdAmbiente()==datos.getIdAmbiente()) {
					datosFinal.setNumCaidas(datos.getNumCaidas());
					break;
				}
			}
		}
		
		return listaConteoFinal;
	}
	
	/**
	 * Valida con base en la hora si una ca&iacute;da marcada a base de datos es nueva, o es continuidad de una anterior.
	 * 
	 * @param horaCompletaAnterior Hora anterior de registro de ca&iacute;da
	 * @param horaCompletaActual Hora actual de registro de ca&iacute;da.
	 * @return 1 si es una ca&iacute;da nueva, 0 en caso contrario.
	 */
	private int validarSiEsLaMismaCaida(String horaCompletaAnterior, String horaCompletaActual) {
		int bandera = 0;
		
		Integer horaActual = Integer.valueOf((horaCompletaActual.substring(0, horaCompletaActual.indexOf(":")).compareTo(""))==0?"0":horaCompletaActual.substring(0, horaCompletaActual.indexOf(":")));
		Integer minutoActual = Integer.valueOf(horaCompletaActual.substring(horaCompletaActual.indexOf(":")+1, horaCompletaActual.length()));
		
		Integer horaAnterior = Integer.valueOf((horaCompletaAnterior.substring(0, horaCompletaAnterior.indexOf(":")).compareTo(""))==0?"0":horaCompletaAnterior.substring(0, horaCompletaAnterior.indexOf(":")));
		Integer minutoAnterior = Integer.valueOf(horaCompletaAnterior.substring(horaCompletaAnterior.indexOf(":")+1, horaCompletaAnterior.length()));
		
		boolean banderaMismaHora = ((minutoActual-1) == minutoAnterior && horaActual == horaAnterior) || (horaActual==horaAnterior && minutoActual== minutoAnterior);
		boolean banderahoraPasada = (minutoAnterior== MINUTO_59 && minutoActual== 0) && ((horaActual-1) == horaAnterior);
						
		if((horaActual == horaAnterior && banderaMismaHora) || banderahoraPasada) {
			bandera = 1;
		}

		return bandera;
	}

	/**
	 * Cuenta las ca&iacute;das registradas por ambiente
	 * 
	 * @param lista Lista que contiene todas las ca&iacute;das registradas en el servidor.
	 * @return Lista con el conteo de ca&iacute;das.
	 */
	private List<CaidasAmbienteDTO> obtenerConteoDeCaidas(List<CaidasAmbienteDTO> lista) {
		
		int indice = 0;
		int caidas = 1;
		Integer ambienteAnterior = null;
		String horaCompletaAnterior = null;
		CaidasAmbienteDTO temporal  = null;
		List<CaidasAmbienteDTO> listaDepurada = new ArrayList<CaidasAmbienteDTO>();
		for(CaidasAmbienteDTO objeto : lista) {
			if(indice==0) {
				ambienteAnterior = objeto.getIdAmbiente();
				horaCompletaAnterior = objeto.getHora();
				
				temporal = new CaidasAmbienteDTO();
				temporal.setIdAmbiente(objeto.getIdAmbiente());
				temporal.setAmbiente(objeto.getAmbiente());
			}

			if(objeto.getIdAmbiente() == ambienteAnterior) {
				if(validarSiEsLaMismaCaida(horaCompletaAnterior, objeto.getHora())==0) {
					caidas++;
				}
				
			} else {
				temporal.setNumCaidas(caidas);
				listaDepurada.add(temporal);
				
				temporal = new CaidasAmbienteDTO();
				temporal.setIdAmbiente(objeto.getIdAmbiente());
				temporal.setAmbiente(objeto.getAmbiente());
				caidas=1;
			}
			
			ambienteAnterior = objeto.getIdAmbiente();
			horaCompletaAnterior = objeto.getHora();
			indice++;
		}
		if (temporal !=null) {
			temporal.setNumCaidas(caidas);
			listaDepurada.add(temporal);
		}
		return listaDepurada;
	}

	boolean esCaidaInmediataAnterior(Date tiempoActual, Date tiempoAnterior) {
		boolean esInmediata=false;
		Calendar calActual = Calendar.getInstance();
		Calendar calAnterior = Calendar.getInstance();
		calActual.setTime(tiempoActual);
		calAnterior.setTime(tiempoAnterior);
		calAnterior.add(Calendar.MINUTE, -1);
		
		//SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
		//LOGGER.info("Comparando: "+ sdf.format(calActual.getTime() ) +"----"+sdf.format(calAnterior.getTime()));
		
		esInmediata=calAnterior.compareTo(calActual)==0;
		
		

		return esInmediata;
	}
	
	@Override
	public TiemposCaidaServidorDTO obtenerTiemposUltimaCaidaServidor(Integer idServidor) {
		//LOGGER.info("SOHE - Entra en obtenerTiemposUltimaCaidaServidor idServidor="+idServidor);
		
		//Traer lista de operaciones por servidor
		ArrayList<MONTOperacionDTO> lsOperacionesByServidor = (ArrayList<MONTOperacionDTO>) operacionDAO.obtenerOperacionesByServidorId(idServidor);
		
		SimpleDateFormat sdf= new SimpleDateFormat("HH:mm");
		Date momentoCaida=new Date();
		String horaAnterior = null;
		Date tiempoAnterior = null;
		Integer mins=0;
		//Recorrer la lista para obtener datos(Hora de inicio y tiempo de caida) de la caída mas reciente
		for (MONTOperacionDTO oper : lsOperacionesByServidor) {
			//LOGGER.info("Operacion: "+oper);
			if(horaAnterior == null) {
				horaAnterior=sdf.format(oper.getFecha());
				tiempoAnterior=oper.getFecha();
				continue;
			}
			
			if(esCaidaInmediataAnterior(oper.getFecha(), tiempoAnterior)) {
				//Misma caida
				//LOGGER.info("Misma caida: "+horaAnterior +" a "+ sdf.format(oper.getFecha()) );
				mins++;
			}else {
				//Nueva caida
				//LOGGER.info("Nueva caida: "+horaAnterior +" a "+ sdf.format(oper.getFecha()) );
				//Setear inicio de caida igual a anterior 
				momentoCaida=tiempoAnterior;
				break;
			}
			
			//Guardamos temporal
			horaAnterior=sdf.format(oper.getFecha());
			tiempoAnterior=oper.getFecha();
	
		}
		
		
		
		
		//Setear tiempos
		TiemposCaidaServidorDTO tiempos = new TiemposCaidaServidorDTO();
		tiempos.setIdservidor(idServidor);
		tiempos.setHoraCaida(new SimpleDateFormat("HH:mm:ss").format(momentoCaida));
		tiempos.setTiempoCaida(mins.toString());
		
		
		return tiempos;
	}
	
	
	/**
	 * 
	 * @return 
	 */
	@Override
	public String obtenerNotificacionCaidas(){
		
		long startTime = System.nanoTime();
		
		//Traer lista de datos de los ambientes para recorrerla y de los caidos ir generando el texto
		List<AmbienteConEstatusDTO> lista = monitorHttpOnDemandService.retrieveEstatusByAmbiente();
		
		//De los caidos agrear información de tiempo de caídas
		//String txtBannerCaida="";
		StringBuilder txtBannerBuilder = new StringBuilder();
		txtBannerBuilder.append("");
		int idServidor=-1;
		int nodoBalanceador=-1;
		TiemposCaidaServidorDTO tmCaida = null;
		LOGGER.info("Tamanio lista: "+lista.size());
		LOGGER.info("----------------------  ----------------------");
		for (AmbienteConEstatusDTO ambEst : lista) {
			LOGGER.info("-----"+ ambEst +" ----");
			//NODOS
			if(ambEst.nodo1.equalsIgnoreCase(Utils.CAIDO)) {
				nodoBalanceador=0;
				idServidor=Utils.ARREGLO_IDS_SERVIDORES[Integer.parseInt(ambEst.idAmbiente)-1][nodoBalanceador];
				//LOGGER.info("SOHE - nodo1 de "+ambEst.getNombreAmbiente()+" --> idServidor:"+idServidor);
				
				if(idServidor >= 0) {
					//txtBannerCaida=txtBannerCaida +llenarAlertaCaida(nodoBalanceador,ambEst,ambEst.nodo1);
					txtBannerBuilder.append(llenarAlertaCaida(nodoBalanceador,ambEst,ambEst.nodo1));	
				}
			}
			if(ambEst.nodo2.equalsIgnoreCase(Utils.CAIDO)) {
				nodoBalanceador=1;
				idServidor=Utils.ARREGLO_IDS_SERVIDORES[Integer.parseInt(ambEst.idAmbiente)-1][nodoBalanceador];
				//LOGGER.info("SOHE - nodo2 de "+ambEst.getNombreAmbiente()+" --> idServidor:"+idServidor);
				
				if(idServidor >= 0) {
					//txtBannerCaida=txtBannerCaida +llenarAlertaCaida(nodoBalanceador,ambEst,ambEst.nodo2);
					txtBannerBuilder.append(llenarAlertaCaida(nodoBalanceador,ambEst,ambEst.nodo2));
				}
			}
			
			//IBM
			if(ambEst.bantotalNodo1.equalsIgnoreCase(Utils.CAIDO)) {
				nodoBalanceador=2;
				idServidor=Utils.ARREGLO_IDS_SERVIDORES[Integer.parseInt(ambEst.idAmbiente)-1][nodoBalanceador];
				//LOGGER.info("SOHE - IBM_nodo1 de "+ambEst.getNombreAmbiente()+" --> idServidor:"+idServidor);
				
				if(idServidor >= 0) {
					tmCaida=obtenerTiemposUltimaCaidaServidor(idServidor);
					if(tmCaida != null) {
						//txtBannerCaida=txtBannerCaida +llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.bantotalNodo1);
						txtBannerBuilder.append(llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.bantotalNodo1));
					}
				}
				
			}
			if(ambEst.bantotalNodo2.equalsIgnoreCase(Utils.CAIDO)) {
				nodoBalanceador=3;
				idServidor=Utils.ARREGLO_IDS_SERVIDORES[Integer.parseInt(ambEst.idAmbiente)-1][nodoBalanceador];
				//LOGGER.info("SOHE - IBM_nodo2 de "+ambEst.getNombreAmbiente()+" --> idServidor:"+idServidor);
				
				if(idServidor >= 0) {
					tmCaida=obtenerTiemposUltimaCaidaServidor(idServidor);
					if(tmCaida != null) {
						//txtBannerCaida=txtBannerCaida +llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.bantotalNodo2);
						txtBannerBuilder.append(llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.bantotalNodo2));
					}
				}
				
			}
			if(ambEst.bantotal.equalsIgnoreCase(Utils.CAIDO)) {
				nodoBalanceador=4;
				idServidor=Utils.ARREGLO_IDS_SERVIDORES[Integer.parseInt(ambEst.idAmbiente)-1][nodoBalanceador];
				//LOGGER.info("SOHE - IBM de "+ambEst.getNombreAmbiente()+" --> idServidor:"+idServidor);
				
				if(idServidor >= 0) {
					tmCaida=obtenerTiemposUltimaCaidaServidor(idServidor);
					if(tmCaida != null) {
						//txtBannerCaida=txtBannerCaida +llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.bantotal);
						txtBannerBuilder.append(llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.bantotal));
					}
				}
				
			}
			
			//SFM
			if(ambEst.sofomNodo1.equalsIgnoreCase(Utils.CAIDO)) {
				nodoBalanceador=5;
				idServidor=Utils.ARREGLO_IDS_SERVIDORES[Integer.parseInt(ambEst.idAmbiente)-1][nodoBalanceador];
				//LOGGER.info("SOHE - SFM_nodo1 de "+ambEst.getNombreAmbiente()+" --> idServidor:"+idServidor);
				
				if(idServidor >= 0) {
					tmCaida=obtenerTiemposUltimaCaidaServidor(idServidor);
					if(tmCaida != null) {
						//txtBannerCaida=txtBannerCaida +llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida, ambEst.sofomNodo1);
						txtBannerBuilder.append(llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.sofomNodo1));
					}
				}
				
			}
			if(ambEst.sofomNodo2.equalsIgnoreCase(Utils.CAIDO)) {
				nodoBalanceador=6;
				idServidor=Utils.ARREGLO_IDS_SERVIDORES[Integer.parseInt(ambEst.idAmbiente)-1][nodoBalanceador];
				//LOGGER.info("SOHE - SFM_nodo2 de "+ambEst.getNombreAmbiente()+" --> idServidor:"+idServidor);
				
				if(idServidor >= 0) {
					tmCaida=obtenerTiemposUltimaCaidaServidor(idServidor);
					if(tmCaida != null) {
						//txtBannerCaida=txtBannerCaida +llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.sofomNodo2);
						txtBannerBuilder.append(llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.sofomNodo2));
					}
				}
				
			}
			if(ambEst.sofom.equalsIgnoreCase(Utils.CAIDO)) {
				nodoBalanceador=7;
				idServidor=Utils.ARREGLO_IDS_SERVIDORES[Integer.parseInt(ambEst.idAmbiente)-1][nodoBalanceador];
				//LOGGER.info("SOHE - SFM de "+ambEst.getNombreAmbiente()+" --> idServidor:"+idServidor);
				
				if(idServidor >= 0) {
					tmCaida=obtenerTiemposUltimaCaidaServidor(idServidor);
					if(tmCaida != null) {
						//txtBannerCaida=txtBannerCaida +llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.sofom);
						txtBannerBuilder.append(llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida,ambEst.sofom));
					}
				}
				
			}
			
//			if(idServidor >= 0) {
//				tmCaida=obtenerTiemposUltimaCaidaServidor(idServidor);
//				if(tmCaida != null) {
//					txtBannerCaida=txtBannerCaida +llenarAlertaCaidaConTiempos(nodoBalanceador,ambEst, tmCaida);
//				}
//			}
			
			//Reset de valores
			tmCaida = null;
			idServidor=-1;
			
		}
		LOGGER.info("----------------------  ----------------------");
		
		long duration = (System.nanoTime() - startTime) / 1000; 
		LOGGER.info("Time taken (in micro) : " + duration);

		
		
		//Validar SIN CAIDAS
		if(txtBannerBuilder.toString().isEmpty()) {
			return "||Sin caídas||";
		}else {
			return  "||".concat(txtBannerBuilder.toString());
		}
		
		
		
	}
	
	String llenarAlertaCaidaConTiempos(int nodoBalanceador,AmbienteConEstatusDTO ambEst,TiemposCaidaServidorDTO tmCaida,String estatus) {
		//LOGGER.info("SOHE - nodoBalanceador: "+nodoBalanceador+" "+ Utils.NODOS_BALANCEADORES[nodoBalanceador]+"-"+ambEst.nombreAmbiente);
		
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append(" ").append(Utils.NODOS_BALANCEADORES[nodoBalanceador]).append("_").append(ambEst.getNombreAmbiente()).append(":").append(estatus)
			.append("(").append(tmCaida.getHoraCaida()).append(" ").append(Utils.TXT_HORAS).append(" - ").append(tmCaida.getTiempoCaida()).append(" ")
			.append(Utils.TXT_MINUTOS).append(") ||");
		
		return sBuilder.toString();
		
	}
	
	String llenarAlertaCaida(int nodoBalanceador,AmbienteConEstatusDTO ambEst,String estatus) {
		//LOGGER.info("SOHE - nodoBalanceador: "+nodoBalanceador+" "+ Utils.NODOS_BALANCEADORES[nodoBalanceador]+"-"+ambEst.nombreAmbiente);
		
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append(" ").append(Utils.NODOS_BALANCEADORES[nodoBalanceador]).append("_").append(ambEst.getNombreAmbiente()).append(":").append(estatus)
			.append(" ||");
		
		return sBuilder.toString();
		
	}
	
	
}
