package com.bancosabadell.monitorAmbientes.monitoreo.service;

import java.util.List;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.DisponibiliadAmbientesDTO;

/**
 * Servicio que se encarga de obtener los datos de disponibilidad de los servidores.
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
public interface DisponibiliadAmbientesService {

	/**
	 * Lista el porcentaje de disponibilidad de todos los servidores.
	 */
	List<DisponibiliadAmbientesDTO> obtenerDisponibilidad();
}
