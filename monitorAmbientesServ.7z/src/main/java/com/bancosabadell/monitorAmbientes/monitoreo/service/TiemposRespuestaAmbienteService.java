package com.bancosabadell.monitorAmbientes.monitoreo.service;

import java.util.List;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.TiempoRespuestaAmbienteDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.TiempoRespuestaAmbienteIndicadorDTO;

public interface TiemposRespuestaAmbienteService {

	List<TiempoRespuestaAmbienteDTO> obtenerTiempos();
	List<TiempoRespuestaAmbienteDTO> obtenerTiemposByAmbiente(String nombreCorto);
	List<TiempoRespuestaAmbienteIndicadorDTO> obtenerIndicadoresTiemposByAmbiente(String nombreCorto);
}
