package com.bancosabadell.monitorAmbientes.monitoreo.dao;

import java.util.List;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.DisponibiliadAmbientesDTO;

public interface DisponibiliadAmbientesDAO {

	/**
	 * Lista el porcentaje de disponibilidad de todos los servidores.
	 */
	List<DisponibiliadAmbientesDTO> obtenerDisponibilidad();
}
