package com.bancosabadell.monitorAmbientes.monitoreo.service;

import java.util.List;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.CaidasAmbienteDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.TiemposCaidaServidorDTO;

public interface CaidasAmbienteService {

	List<CaidasAmbienteDTO> obtenerCaidas();
	List<CaidasAmbienteDTO> obtenerCaidasByNombreCorto(String nombreCorto);
	List<CaidasAmbienteDTO> obtenerCaidaDeNodoPorIdServidor(String identificadorDeBusqueda, Integer bandera);
	List<CaidasAmbienteDTO> obtenerCaidasDeAmbientePorNombreCorto(String nombreCorto);
	List<CaidasAmbienteDTO> contarCaidasDeAmbientePorNombreCorto(String nombreCorto);
	//TODO regresar DTO con información del tiempo y hora de la ultima caida para un servidor dado(idServidor)
	TiemposCaidaServidorDTO obtenerTiemposUltimaCaidaServidor(Integer idServidor);
	String obtenerNotificacionCaidas();
}
