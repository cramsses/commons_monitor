package com.bancosabadell.monitorAmbientes.monitoreo.dto;

public class TiemposCaidaServidorDTO {
	
	private Integer idservidor;
	private String horaCaida;
	private String tiempoCaida;
	public Integer getIdservidor() {
		return idservidor;
	}
	public void setIdservidor(Integer idservidor) {
		this.idservidor = idservidor;
	}
	public String getHoraCaida() {
		return horaCaida;
	}
	public void setHoraCaida(String horaCaida) {
		this.horaCaida = horaCaida;
	}
	public String getTiempoCaida() {
		return tiempoCaida;
	}
	public void setTiempoCaida(String tiempoCaida) {
		this.tiempoCaida = tiempoCaida;
	}
	
	

}
