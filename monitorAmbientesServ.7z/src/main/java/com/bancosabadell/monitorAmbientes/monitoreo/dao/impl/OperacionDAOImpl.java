package com.bancosabadell.monitorAmbientes.monitoreo.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bancosabadell.monitorAmbientes.monitoreo.dao.OperacionDAO;
import com.bancosabadell.monitorAmbientes.monitoreo.dao.mapper.OperacionesMapper;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.MONTOperacionDTO;

@Repository
public class OperacionDAOImpl implements OperacionDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final Logger LOGGER = Logger.getLogger(OperacionDAOImpl.class);
	
	private static final String OBTENER_OPERACIONES_BY_SERVIDOR=""+
			"SELECT oper.idoperacion,oper.idservidor,oper.idestatus, oper.fecha AS FECHA,oper.tiemporespuesta,oper.idtipoverificacion " + 
			"FROM mont_operacion oper " + 
			"WHERE oper.idservidor=? " + 
			"AND (FECHA >= trunc(sysdate) And FECHA < trunc(sysdate) +  1) " +
			"AND oper.IDESTATUS not in (200, 401) "+
			"ORDER BY oper.idoperacion DESC,oper.fecha DESC";
	
	@Override
	public List<MONTOperacionDTO> obtenerOperacionesByServidorId(int idServidor) {
		LOGGER.info("SOHE - obtenerOperacionesByServidorId("+idServidor+")");
		List<MONTOperacionDTO> ls=null;
		try {
			ls= jdbcTemplate.query(OBTENER_OPERACIONES_BY_SERVIDOR, new Object[] {idServidor}, new OperacionesMapper());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ls;
	}

}
