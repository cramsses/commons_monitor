package com.bancosabadell.monitorAmbientes.monitoreo.service.impl;

import java.util.concurrent.Callable;

import org.apache.log4j.Logger;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.AmbienteConEstatusDTO;
import com.bancosabadell.monitorAmbientes.utils.Utils;

public class SetterToObject  implements Callable<AmbienteConEstatusDTO> {

	
	private String nodo;
	private int bandera;
	private String campo;
	private AmbienteConEstatusDTO objeto;
	private AmbienteConEstatusDTO objetoEntrada;
	

	
	private static final Logger LOGGER = Logger.getLogger(SetterToObject.class);
	
	public SetterToObject(AmbienteConEstatusDTO objeto,String nodo,String campo, int bandera, AmbienteConEstatusDTO objetoEntrada) {
		this.objeto=objeto;
		this.nodo = nodo;
		this.campo = campo;
		this.bandera = bandera;
		this.objetoEntrada=objetoEntrada;
	}
	
	@Override
	public AmbienteConEstatusDTO call() throws Exception {
		AmbienteConEstatusDTO objeto = asignarValores(this.campo);
		return objeto;
		
	}
	
	private AmbienteConEstatusDTO asignarValores (String campo) throws InstantiationException, IllegalAccessException  {
	    Class<?> clase;	
		try {
			clase = Class.forName("com.bancosabadell.monitorAmbientes.monitoreo.dto.AmbienteConEstatusDTO");
			clase.getDeclaredField(campo).set(this.objeto, asignarValorACampo());
			
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return this.objeto;
	}
	
	private String asignarValorACampo() {	
		String resultado = null;
		if(nodo != null) {
			if (bandera==0) {
				resultado = Utils.hacerPing(nodo)?Utils.OK:Utils.CAIDO;
			} else if (bandera==1) {
				resultado = Utils.validarEstatusURL(nodo)==Utils.OK_STATUS?Utils.OK:Utils.CAIDO;
				LOGGER.info("JAHO - URL: "+nodo+", estado: "+resultado);
			}
		}else {
			resultado=Utils.NO_APLICA;
		}
		if(this.objetoEntrada.getIdEstatus()!=null && this.objetoEntrada.getIdEstatus().compareTo("1")!=0) {
			resultado=Utils.NO_APLICA;
		}
		
		return resultado;
	}
}
