package com.bancosabadell.monitorAmbientes.monitoreo.service;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.DisponibilidadDetalleListsDTO;

public interface DisponibilidadDetalleService {
	
	DisponibilidadDetalleListsDTO obtenerDetalleDisponibilidad();

}
