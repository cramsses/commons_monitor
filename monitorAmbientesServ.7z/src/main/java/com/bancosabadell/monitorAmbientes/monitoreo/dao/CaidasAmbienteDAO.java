package com.bancosabadell.monitorAmbientes.monitoreo.dao;

import java.util.List;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.CaidasAmbienteDTO;

/**
 * Interfaz que obtiene la informaci&oacute;n de las ca&iacute;das registradas en uno o varios
 * ambientes.
 * 
 * @author Jesus Alfredo Hernandez Orozco.
 *
 */
public interface CaidasAmbienteDAO {

	List<CaidasAmbienteDTO> obtenerCaidasAmbiente();
	
	List<CaidasAmbienteDTO> obtenerCaidasByNombreCortoAmbiente(String nombreCorto);
	
	/**
	 * Obtiene el listado de las caidas que ha habido en un nodo o en una URL de Bantotal o SOFOM.
	 * 
	 * @param idServidor ID del servidor.
	 * @return Listado de las caidas que ha habido en un nodo o en una URL de Bantotal o SOFOM.
	 */
	List<CaidasAmbienteDTO> obtenerCaidaDeNodoPorIdServidor(String query, String identificadorDeBusqueda);
	
	/**
	 * Obtiene los identificadores de servidor que pertenecen a un nombre corto de ambiente.
	 * 
	 * @param nombreCorto nombre corto del ambiente que se pretende consultar.
	 * @return Lista de identificadores de servidor
	 */
	List<Integer> obtenerIDdeServidoresPorNombreCorto(String nombreCorto);
	
	/**
	 * Obtiene las caidas de las URL de un ambiente en particular filtrando por los IDs del servidor
	 */
	List<CaidasAmbienteDTO> obtenerCaidasDeAmbientePorNombreCorto(String ids);
}
