package com.bancosabadell.monitorAmbientes.monitoreo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bancosabadell.monitorAmbientes.monitoreo.dao.DisponibiliadAmbientesDAO;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.DisponibiliadAmbientesDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.service.DisponibiliadAmbientesService;

/**
 * Servicio que se encarga de obtener los datos de disponibilidad de los servidores.
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
@Service
public class DisponibiliadAmbientesServiceImpl implements DisponibiliadAmbientesService {

	public DisponibiliadAmbientesServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Autowired
	private DisponibiliadAmbientesDAO disponibiliadAmbientesDAO;
	
	/**
	 * Lista el porcentaje de disponibilidad de todos los servidores.
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = true)
	public List<DisponibiliadAmbientesDTO> obtenerDisponibilidad() {
		return disponibiliadAmbientesDAO.obtenerDisponibilidad();
	}

}
