package com.bancosabadell.monitorAmbientes.monitoreo.service;

public interface MonitorHttpExecutor {
	
}
