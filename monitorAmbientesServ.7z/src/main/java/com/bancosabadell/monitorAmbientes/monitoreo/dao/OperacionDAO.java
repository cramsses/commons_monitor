package com.bancosabadell.monitorAmbientes.monitoreo.dao;

import java.util.List;

import com.bancosabadell.monitorAmbientes.monitoreo.dto.MONTOperacionDTO;


public interface OperacionDAO {

	List<MONTOperacionDTO> obtenerOperacionesByServidorId(int idServidor);
	
}
