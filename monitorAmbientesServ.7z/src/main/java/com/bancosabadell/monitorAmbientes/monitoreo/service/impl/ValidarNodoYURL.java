package com.bancosabadell.monitorAmbientes.monitoreo.service.impl;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class ValidarNodoYURL implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
