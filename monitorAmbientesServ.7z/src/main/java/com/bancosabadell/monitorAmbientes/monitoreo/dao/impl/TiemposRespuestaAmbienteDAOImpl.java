package com.bancosabadell.monitorAmbientes.monitoreo.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bancosabadell.monitorAmbientes.monitoreo.dao.TiempoRespuestaAmbienteDAO;
import com.bancosabadell.monitorAmbientes.monitoreo.dao.mapper.TiempoRespuetaAmbienteMapper;
import com.bancosabadell.monitorAmbientes.monitoreo.dao.mapper.TiempoRespuetaAmbientenIndicadorMapper;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.TiempoRespuestaAmbienteDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.dto.TiempoRespuestaAmbienteIndicadorDTO;

@Repository
public class TiemposRespuestaAmbienteDAOImpl implements TiempoRespuestaAmbienteDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final 
	String QRY_TIEMPO_RESPUESTA_AMBIENTE="SELECT ambi.idambiente,\r\n" + 
			"      ambi.NOMBREAMBIENTE,\r\n" + 
			"      to_char(FECHA, 'HH24:MI') as HORA,\r\n" + 
			"      oper.TIEMPORESPUESTA   as AVG\r\n" + 
			" FROM mont_operacion oper \r\n" + 
			" INNER JOIN mona_servidores serv  ON oper.IDSERVIDOR=serv.IDSERVIDOR   \r\n" + 
			" INNER JOIN monc_ambientes ambi  ON serv.IDAMBIENTE=ambi.IDAMBIENTE  \r\n" + 
			" INNER JOIN mona_url url on serv.idurl=url.idurl  \r\n" + 
			" WHERE (FECHA >= trunc(sysdate) And FECHA < trunc(sysdate) +  1)  \r\n" + 
			" AND url.idurl in (3,6,9,12,15,18,21,24,25)\r\n" + 
			" ORDER BY ambi.idambiente";
	
	/**
	 * Cada ambiente contiene una o mas urls por lo que se toma el promedio,
	 * Por fines practicos se toma solo balanceador
	 */
	private static final 
	String QRY_TIEMPO_RESPUESTA_BY_AMBIENTE="SELECT ambi.idambiente, ambi.NOMBREAMBIENTE, to_char(FECHA, 'HH24:MI') as HORA, oper.TIEMPORESPUESTA as AVG\r\n" + 
			"FROM mont_operacion oper        \r\n" + 
			"INNER JOIN mona_servidores serv  ON oper.IDSERVIDOR=serv.IDSERVIDOR        \r\n" + 
			"INNER JOIN monc_ambientes ambi  ON serv.IDAMBIENTE=ambi.IDAMBIENTE  \r\n" + 
			"INNER JOIN mona_url url on serv.idurl=url.idurl\r\n" + 
			"INNER JOIN monc_aplicacion app on app.idapp = url.idtipoapp\r\n" + 
			"WHERE (FECHA >= trunc(sysdate) And FECHA < trunc(sysdate) +  1)      \r\n" + 
			"AND ambi.NOMBRECORTO= ?   \r\n" + 
			"AND url.idurl in (3,6,9,12,15,18,21,24,25)\r\n" + 
			"ORDER BY ambi.idambiente,to_char(FECHA, 'HH24:MI')";
	
	private static final 
	String QRY_TIEMPO_RESPUESTA_INDICADORES_BY_AMBIENTE="SELECT ambi.idambiente,   " + 
			"      ambi.NOMBREAMBIENTE,  \r\n" + 
			"      CAST(AVG(oper.TIEMPORESPUESTA) AS DECIMAL(10,3))   as AVG,   " + 
			"      MAX(oper.TIEMPORESPUESTA) as MAX,  " + 
			"      MIN(oper.TIEMPORESPUESTA) as MIN   " + 
			" FROM mont_operacion oper" + 
			" INNER JOIN mona_servidores serv  ON oper.IDSERVIDOR=serv.IDSERVIDOR  " + 
			" INNER JOIN monc_ambientes ambi  ON serv.IDAMBIENTE=ambi.IDAMBIENTE " + 
			" INNER JOIN mona_url url on serv.idurl=url.idurl " + 
			" INNER JOIN monc_aplicacion app on app.idapp = url.idtipoapp " + 
			" WHERE (FECHA >= trunc(sysdate) And FECHA < trunc(sysdate) +  1) " + 
			" AND ambi.NOMBRECORTO= ? " + 
			" AND url.idurl in (3,6,9,12,15,18,21,24,25) " + 
			" GROUP BY ambi.IDAMBIENTE, ambi.NOMBREAMBIENTE  " + 
			" ORDER BY ambi.idambiente";
	

	@Override
	public List<TiempoRespuestaAmbienteDTO> obtenerTiemposRespuestaAmbiente() {
		return jdbcTemplate.query(QRY_TIEMPO_RESPUESTA_AMBIENTE, new TiempoRespuetaAmbienteMapper());
	}


	@Override
	public List<TiempoRespuestaAmbienteDTO> obtenerTiemposRespuestaByAmbiente(String nombreCorto) {
		return jdbcTemplate.query(QRY_TIEMPO_RESPUESTA_BY_AMBIENTE, new Object[] {nombreCorto}, new TiempoRespuetaAmbienteMapper());
	}


	@Override
	public List<TiempoRespuestaAmbienteIndicadorDTO> obtenerIndicadoresTiemposRespuestaByAmbiente(String nombreCorto) {
		return jdbcTemplate.query(QRY_TIEMPO_RESPUESTA_INDICADORES_BY_AMBIENTE, new Object[] {nombreCorto}, new TiempoRespuetaAmbientenIndicadorMapper());
	}
}