package com.bancosabadell.monitorAmbientes.catalogos.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bancosabadell.monitorAmbientes.catalogos.dao.MonaServidoresDao;
import com.bancosabadell.monitorAmbientes.catalogos.service.MonaServidoresService;
import com.bancosabadell.monitorAmbientes.dto.MonaServidoresDTO;
import com.bancosabadell.monitorAmbientes.monitoreo.dao.CaidasAmbienteDAO;

@Service
public class MonaServidoresServiceImpl implements MonaServidoresService {

	@Autowired 
	private MonaServidoresDao monaServidoresDao;
	
	@Autowired
	private CaidasAmbienteDAO caidasAmbienteDAO;
	
	public MonaServidoresServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = true)
	public List<MonaServidoresDTO> obtenerServidoresPorIDs(String nombreCorto) {
		List <Integer> listaDeIdDeServidores = caidasAmbienteDAO.obtenerIDdeServidoresPorNombreCorto(nombreCorto);
		return monaServidoresDao.obtenerServidoresPorIDs(retornarIds(listaDeIdDeServidores));
	}
	
	private String retornarIds(List <Integer> listaDeIdDeServidores) {
		StringBuilder idServidores = new StringBuilder();
		idServidores.append("(");
		for (Integer id : listaDeIdDeServidores) {
			idServidores.append(id+",");
		}
		idServidores.append(")");
		return idServidores.toString().replace(",)", ")");
	}
}