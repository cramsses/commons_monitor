package com.bancosabadell.monitorAmbientes.catalogos.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bancosabadell.monitorAmbientes.catalogos.dao.MoncNodosDAO;
import com.bancosabadell.monitorAmbientes.catalogos.mapper.MoncNodosMapper;
import com.bancosabadell.monitorAmbientes.dto.MoncNodosDTO;

/**
 * Clase de acceso a datos para la tabla Monc_Nodos
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
@Repository
public class MoncNodosDAOImpl implements MoncNodosDAO {

	public MoncNodosDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final String OBTENER_NODO_POR_NOMBRECORTO = "select IDNODO, NOMNODO, IPNODO, FECHAINICIO, FECHAFIN, DISPONIBILIDAD_REQ from (\r\n" + 
			"    select rownum as indice, a.IDNODO, a.NOMNODO, a.IPNODO, a.FECHAINICIO, a.FECHAFIN, a.DISPONIBILIDAD_REQ \r\n" + 
			"    from MONC_NODOS a \r\n" + 
			"    inner join mona_servidores b on (b.IDNODO = a.IDNODO) \r\n" + 
			"    inner join monc_ambientes  c on (b.idambiente = c.idambiente) \r\n"+
			"    inner join mona_url        d on (d.idurl=b.idurl)    \r\n" + 
			"    inner join monc_aplicacion e on (e.idapp=d.idtipoapp) \r\n" + 
			"    where c.nombrecorto=?  and d.idtipoapp=1 \r\n" + 
			") where indice=? ";

	/**
	 * Obtiene el nombre y la IP del nodo a partir del nombre corto del ambiente
	 * 
	 * @param nombreCorto Nombre corto del ambiente. Ejemplo: Desarrollo, DES.
	 * @param indice Registro aconsultar en BD
	 * @return Objeto con el nombre y la IP del nodo a partir del nombre corto del ambiente
	 */
	@Override
	public MoncNodosDTO obtenerInformacionDeNodoPorNombreCorto(String nombreCorto, Integer indice) {
		return jdbcTemplate.queryForObject(OBTENER_NODO_POR_NOMBRECORTO, new Object[] {nombreCorto, indice}, new MoncNodosMapper());
	}

}
