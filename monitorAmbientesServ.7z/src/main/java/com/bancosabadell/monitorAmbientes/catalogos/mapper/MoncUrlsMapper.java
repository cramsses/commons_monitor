package com.bancosabadell.monitorAmbientes.catalogos.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bancosabadell.monitorAmbientes.dto.MoncURLDTO;

/**
 * Mapea los datos de la tabla monc_urls con los del objeto MoncNodosDTO
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
public class MoncUrlsMapper implements RowMapper<MoncURLDTO> {

	public MoncUrlsMapper() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public MoncURLDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		MoncURLDTO objeto = new MoncURLDTO();
		objeto.setIdURL(rs.getInt("IDURL"));
		objeto.setIdTipoApp(rs.getInt("IDTIPOAPP"));
		objeto.setDireccion(rs.getString("DIRECCION"));
		objeto.setPuerto(rs.getInt("PUERTO"));
		objeto.setIp(rs.getString("IP"));
		objeto.setFechaInicio(rs.getDate("FECHAINICIO"));
		objeto.setFechaFin(rs.getDate("FECHAFIN"));
		objeto.setDisponibilidadReq(rs.getFloat("DISPONIBILIDAD_REQ"));
		return objeto;
	}

}
