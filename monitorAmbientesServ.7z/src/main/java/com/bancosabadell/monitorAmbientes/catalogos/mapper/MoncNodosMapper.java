package com.bancosabadell.monitorAmbientes.catalogos.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bancosabadell.monitorAmbientes.dto.MoncNodosDTO;

/**
 * Mapea los datos de la tabla monc_nodos con los del objeto MoncNodosDTO
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
public class MoncNodosMapper implements RowMapper <MoncNodosDTO> {

	public MoncNodosMapper() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public MoncNodosDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		MoncNodosDTO objeto = new MoncNodosDTO();
		objeto.setIdNodo(rs.getInt("IDNODO"));
		objeto.setNomNodo(rs.getString("NOMNODO"));
		objeto.setIpNodo(rs.getString("IPNODO"));
		objeto.setFechaInicio(rs.getDate("FECHAINICIO"));
		objeto.setFechafin(rs.getDate("FECHAFIN"));
		objeto.setDisponibilidadReq(rs.getFloat("DISPONIBILIDAD_REQ"));
		return objeto;
	}

}
