package com.bancosabadell.monitorAmbientes.catalogos.service;

import java.util.List;

import com.bancosabadell.monitorAmbientes.dto.MonaServidoresDTO;

public interface MonaServidoresService {

	List<MonaServidoresDTO> obtenerServidoresPorIDs(String nombreCorto);
}
