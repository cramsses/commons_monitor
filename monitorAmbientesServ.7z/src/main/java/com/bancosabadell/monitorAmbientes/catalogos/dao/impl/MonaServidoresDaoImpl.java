package com.bancosabadell.monitorAmbientes.catalogos.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bancosabadell.monitorAmbientes.catalogos.dao.MonaServidoresDao;
import com.bancosabadell.monitorAmbientes.catalogos.mapper.MonaServidoresMapper;
import com.bancosabadell.monitorAmbientes.dto.MonaServidoresDTO;

/**
 * Obtiene los datos asociados a la tabla de MONA_SERVODORES
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
@Repository
public class MonaServidoresDaoImpl implements MonaServidoresDao {

	private static final String OBTENER_SERVIDORES_POR_IDS="select * from mona_servidores where idservidor in ";
	
	public MonaServidoresDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public List<MonaServidoresDTO> obtenerServidoresPorIDs(String ids) {
		return jdbcTemplate.query(OBTENER_SERVIDORES_POR_IDS+ids, new MonaServidoresMapper());
	}
}
