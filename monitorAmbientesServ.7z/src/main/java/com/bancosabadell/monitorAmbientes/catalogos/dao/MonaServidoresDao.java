package com.bancosabadell.monitorAmbientes.catalogos.dao;

import java.util.List;

import com.bancosabadell.monitorAmbientes.dto.MonaServidoresDTO;

/**
 * Obtiene los datos asociados a la tabla de MONA_SERVODORES
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
public interface MonaServidoresDao {

	List<MonaServidoresDTO> obtenerServidoresPorIDs(String ids);
}
