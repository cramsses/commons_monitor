package com.bancosabadell.monitorAmbientes.catalogos.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bancosabadell.monitorAmbientes.dto.MonaServidoresDTO;

public class MonaServidoresMapper implements RowMapper<MonaServidoresDTO> {

	public MonaServidoresMapper() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public MonaServidoresDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		MonaServidoresDTO objeto = new MonaServidoresDTO();
		objeto.setIdServidor(rs.getInt("IDSERVIDOR"));
		objeto.setIdNodo(rs.getInt("IDNODO"));
		objeto.setIdURL(rs.getInt("IDURL"));
		objeto.setIdTipoServ(rs.getInt("IDTIPOSERV"));
		objeto.setDescripcion(rs.getString("DESCRIPCIONSERVIDOR"));
		objeto.setIdAmbiente(rs.getInt("IDAMBIENTE"));
		objeto.setFechaInicio(rs.getDate("FECHAINICIO"));
		objeto.setFechaFin(rs.getDate("FECHAFIN"));
		objeto.setIdEstatus(rs.getInt("IDESTATUS"));
		return objeto;
	}
}