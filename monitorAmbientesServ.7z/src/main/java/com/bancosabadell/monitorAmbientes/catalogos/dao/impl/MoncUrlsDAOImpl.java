package com.bancosabadell.monitorAmbientes.catalogos.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bancosabadell.monitorAmbientes.catalogos.dao.MoncUrlsDAO;
import com.bancosabadell.monitorAmbientes.catalogos.mapper.MoncUrlsMapper;
import com.bancosabadell.monitorAmbientes.dto.MoncURLDTO;

/**
 * Clase de acceso a datos para la tabla Monc_Urls
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
@Repository
public class MoncUrlsDAOImpl implements MoncUrlsDAO {

	public MoncUrlsDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final String OBTENER_URL_POR_NOMBRECORTO="select IDURL, IDTIPOAPP, DIRECCION, PUERTO, IP, FECHAINICIO, FECHAFIN, DISPONIBILIDAD_REQ from (\r\n" + 
		"    select rownum as indice, a.IDURL, a.IDTIPOAPP, a.DIRECCION, a.PUERTO, a.IP, a.FECHAINICIO, a.FECHAFIN, a.DISPONIBILIDAD_REQ\r\n" + 
		"    from mona_url a \r\n" + 
		"    inner join mona_servidores b on (b.idurl = a.idurl)           \r\n" + 
		"    inner join monc_ambientes  c on (b.idambiente = c.idambiente) \r\n" + 
		"    where c.nombrecorto=? \r\n" + 
		") where indice=? ";

	/**
	 * Obtiene la informaci&oacute;n de una URL a partir del nombre corto del nodo y un &iacute;ndice de 
	 * consulta.
	 * 
	 * @param nombreCorto nombre corto del almbiente.
	 * @param indice puntero de referencia que se utilia para la consulta.
	 * @return objeto MoncURLDTO
	 */
	@Override
	public MoncURLDTO obtenerInformacionDeURLPorNombreCorto(String nombreCorto, Integer indice) {
		return jdbcTemplate.queryForObject(OBTENER_URL_POR_NOMBRECORTO, new Object[] {nombreCorto, indice}, new MoncUrlsMapper());
	}

}
