package com.bancosabadell.monitorAmbientes.catalogos.dao;

import com.bancosabadell.monitorAmbientes.dto.MoncURLDTO;

/**
 * Clase de acceso a datos para la tabla Monc_Urls
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
public interface MoncUrlsDAO {

	/**
	 * Obtiene la informaci&oacute;n de una URL a partir del nombre corto del nodo y un &iacute;ndice de 
	 * consulta.
	 * 
	 * @param nombreCorto nombre corto del almbiente.
	 * @param indice puntero de referencia que se utilia para la consulta.
	 * @return objeto MoncURLDTO
	 */
	MoncURLDTO obtenerInformacionDeURLPorNombreCorto(String nombreCorto, Integer indice);
}
