package com.bancosabadell.monitorAmbientes.catalogos.dao;

import com.bancosabadell.monitorAmbientes.dto.MoncNodosDTO;

/**
 * Clase de acceso a datos para la tabla Monc_Nodos
 * 
 * @author Jesus Alfredo Hernandez Orozco
 *
 */
public interface MoncNodosDAO {

	/**
	 * Obtiene el nombre y la IP del nodo a partir del nombre corto del ambiente
	 * 
	 * @param nombreCorto Nombre corto del ambiente. Ejemplo: Desarrollo, DES.
	 * @param indice Registro aconsultar en BD
	 * @return Objeto con el nombre y la IP del nodo a partir del nombre corto del ambiente
	 */
	MoncNodosDTO obtenerInformacionDeNodoPorNombreCorto(String nombreCorto, Integer indice);
}