package com.bancosabadell.monitorAmbientes.dto;

import java.util.Date;

public class MonaServidoresDTO {
	
	public MonaServidoresDTO() {
		// TODO Auto-generated constructor stub
	}
	private Integer idServidor;
	private Integer idURL;
	private Integer idNodo;
	private Integer idTipoServ;
	private String descripcion;
	private Integer idAmbiente;
	private Date fechaInicio;
	private Date fechaFin;
	private Integer idEstatus;
	
	public Integer getIdServidor() {
		return idServidor;
	}
	public void setIdServidor(Integer idServidor) {
		this.idServidor = idServidor;
	}
	public Integer getIdURL() {
		return idURL;
	}
	
	public Integer getIdNodo() {
		return idNodo;
	}
	public void setIdNodo(Integer idNodo) {
		this.idNodo = idNodo;
	}
	public void setIdURL(Integer idURL) {
		this.idURL = idURL;
	}
	public Integer getIdTipoServ() {
		return idTipoServ;
	}
	public void setIdTipoServ(Integer idTipoServ) {
		this.idTipoServ = idTipoServ;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Integer getIdAmbiente() {
		return idAmbiente;
	}
	public void setIdAmbiente(Integer idAmbiente) {
		this.idAmbiente = idAmbiente;
	}
	public Date getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	public Integer getIdEstatus() {
		return idEstatus;
	}
	public void setIdEstatus(Integer idEstatus) {
		this.idEstatus = idEstatus;
	}
	@Override
	public String toString() {
		return "MonaServidoresDTO [idServidor=" + idServidor + ", idURL=" + idURL + ", idNodo=" + idNodo
				+ ", idTipoServ=" + idTipoServ + ", descripcion=" + descripcion + ", idAmbiente=" + idAmbiente
				+ ", fechaInicio=" + fechaInicio + ", fechaFin=" + fechaFin + ", idEstatus=" + idEstatus + "]";
	}
}
