package com.bancosabadell.monitorAmbientes.dto;

import java.util.Date;

public class MoncURLDTO {

	public MoncURLDTO() {
		// TODO Auto-generated constructor stub
	}
	private Integer idURL;
	private Integer idTipoApp;
	private String direccion;
	private Integer puerto;
	private String ip;
	private Date fechaInicio;
	private Date fechaFin;
	private Float disponibilidadReq;
	
	public Integer getIdURL() {
		return idURL;
	}
	public void setIdURL(Integer idURL) {
		this.idURL = idURL;
	}
	public Integer getIdTipoApp() {
		return idTipoApp;
	}
	public void setIdTipoApp(Integer idTipoApp) {
		this.idTipoApp = idTipoApp;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public Integer getPuerto() {
		return puerto;
	}
	public void setPuerto(Integer puerto) {
		this.puerto = puerto;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public Date getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	public Float getDisponibilidadReq() {
		return disponibilidadReq;
	}
	public void setDisponibilidadReq(Float disponibilidadReq) {
		this.disponibilidadReq = disponibilidadReq;
	}
	@Override
	public String toString() {
		return "MoncURLDTO [idURL=" + idURL + ", idTipoApp=" + idTipoApp + ", direccion=" + direccion + ", puerto="
				+ puerto + ", ip=" + ip + ", fechaInicio=" + fechaInicio + ", fechaFin=" + fechaFin
				+ ", disponibilidadReq=" + disponibilidadReq + "]";
	}
}
