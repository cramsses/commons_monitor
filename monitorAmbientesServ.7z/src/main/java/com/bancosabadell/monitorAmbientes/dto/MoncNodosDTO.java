package com.bancosabadell.monitorAmbientes.dto;

import java.util.Date;

public class MoncNodosDTO {

	public MoncNodosDTO() {
		// TODO Auto-generated constructor stub
	}
	private Integer idNodo;
	private String nomNodo;
	private String ipNodo;
	private Date fechaInicio;
	private Date fechafin;
	private Float disponibilidadReq;
	
	public Integer getIdNodo() {
		return idNodo;
	}
	public void setIdNodo(Integer idNodo) {
		this.idNodo = idNodo;
	}
	public String getNomNodo() {
		return nomNodo;
	}
	public void setNomNodo(String nomNodo) {
		this.nomNodo = nomNodo;
	}
	public String getIpNodo() {
		return ipNodo;
	}
	public void setIpNodo(String ipNodo) {
		this.ipNodo = ipNodo;
	}
	public Date getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechafin() {
		return fechafin;
	}
	public void setFechafin(Date fechafin) {
		this.fechafin = fechafin;
	}
	public Float getDisponibilidadReq() {
		return disponibilidadReq;
	}
	public void setDisponibilidadReq(Float disponibilidadReq) {
		this.disponibilidadReq = disponibilidadReq;
	}
	@Override
	public String toString() {
		return "MoncNodosDTO [idNodo=" + idNodo + ", nomNodo=" + nomNodo + ", ipNodo=" + ipNodo + ", fechaInicio="
				+ fechaInicio + ", fechafin=" + fechafin + ", disponibilidadReq=" + disponibilidadReq + "]";
	}
}
