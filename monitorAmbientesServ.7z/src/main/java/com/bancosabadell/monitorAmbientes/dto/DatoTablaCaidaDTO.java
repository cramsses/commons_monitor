package com.bancosabadell.monitorAmbientes.dto;

public class DatoTablaCaidaDTO {
	
	private String hora;
	private Integer caida;

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public Integer getCaida() {
		return caida;
	}

	public void setCaida(Integer caida) {
		this.caida = caida;
	}

	public DatoTablaCaidaDTO() {
		// TODO Auto-generated constructor stub
	}
}