package com.bancosabadell.monitorAmbientes;

public class JpaTest {

	public static void main(String[] args) {
		Integer idAmbiente=1;
		System.out.println("Test de JPA - Find By Id ");
		
//		AmbientesHome ambHome= new AmbientesHome();
		
//		Ambientes ambInsert = new Ambientes(idAmbiente, "ACEP_IBM");
//		ambHome.persist(ambInsert);
		
		
//		Ambientes ambFind =ambHome.findById(idAmbiente);
//		
//		
//		if (ambFind != null) {
//			System.out.println("Ambiente encontrado:"+ambFind.getDescripcionambiente());
//		}else {
//			System.out.println("Ambiente no encontrado con id: "+idAmbiente);
//		}
		

	}

}
