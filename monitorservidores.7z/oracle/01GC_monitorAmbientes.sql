alter session set "_ORACLE_SCRIPT"=true;  
create tablespace ts_monitoreo logging datafile 'C:/opt/oracle/data/ts_sth.dbf' size 128m autoextend on next 32m maxsize 2048m;
create user BDD_BTIBM_GOS identified by lazelot98 default tablespace ts_monitoreo quota 128m on ts_monitoreo temporary tablespace temp account unlock;
grant connect, resource, dba to BDD_BTIBM_GOS;
