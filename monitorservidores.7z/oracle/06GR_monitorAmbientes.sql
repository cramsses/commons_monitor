REVOKE privileges ON 'monitor' FROM 'localhost';

DROP USER monitor;

DROP DATABASE monitoreo;