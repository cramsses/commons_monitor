REVOKE ALL ON *.* FROM 'monitor'@'localhost';

DROP USER monitor@localhost;

DROP DATABASE monitoreo;