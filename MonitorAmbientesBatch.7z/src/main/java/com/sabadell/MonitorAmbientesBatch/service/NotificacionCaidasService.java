package com.sabadell.MonitorAmbientesBatch.service;

public interface NotificacionCaidasService {
	
	
	
	void notificarCaidas();
	
}
